﻿namespace QueR.BLL.Services.Identity
{
    public class LoginResponse
    {
        public string Token { get; set; }
    }
}