﻿using System;

namespace QueR.Domain
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
