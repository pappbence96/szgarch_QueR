﻿namespace QueR.Domain
{
    public enum Gender
    {
        Male, Female, Other
    }
}