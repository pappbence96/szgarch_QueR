import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-menu-page',
  templateUrl: './manager-menu-page.component.html',
  styleUrls: ['./manager-menu-page.component.css']
})
export class ManagerMenuPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
