import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-menu-page',
  templateUrl: './administrator-menu-page.component.html',
  styleUrls: ['./administrator-menu-page.component.scss']
})
export class AdministratorMenuPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
