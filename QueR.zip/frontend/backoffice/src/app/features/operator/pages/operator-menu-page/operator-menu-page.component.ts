import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operator-menu-page',
  templateUrl: './operator-menu-page.component.html',
  styleUrls: ['./operator-menu-page.component.scss']
})
export class OperatorMenuPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onMenuItemSelected(item: number): void {

  }

}
